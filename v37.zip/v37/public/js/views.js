/**
 * views.js — Pure render functions untuk Nintendo 2001 chrome style.
 *
 * Setiap fungsi mengembalikan string HTML yang menggunakan design system
 * class `n-*` (dari public/css/nintendo.css).
 *
 * Layout untuk Android (touch-first):
 *  - Semua touch target minimal 44px
 *  - touch-action: manipulation di button
 *  - Padding cukup untuk jari
 */

const Views = {
  // ════════════════════════════════════════════════════════════
  // Top Nav (Carbon Navy dengan halftone)
  // ════════════════════════════════════════════════════════════
  topNav(opts = {}) {
    const { activeTab, roomCode, mode } = opts;
    return `
      <nav class="n-nav">
        <a class="n-nav__brand" href="#" id="nav-home" style="text-decoration: none; display: flex; align-items: center;">
          <span class="n-nav__brand-emoji">🏯</span>
          <span class="n-nav__brand-text">IKUZE JAPAN</span>
        </a>
        <div class="n-nav__menu">
          ${activeTab === 'lobby' ? '<button class="n-nav__menu-item n-nav__menu-item--active">Lobby</button>' : '<button class="n-nav__menu-item" data-go="lobby">Lobby</button>'}
          ${activeTab === 'room' ? '<button class="n-nav__menu-item n-nav__menu-item--active">Room</button>' : '<button class="n-nav__menu-item" data-go="room">Room</button>'}
          ${activeTab === 'battle' ? '<button class="n-nav__menu-item n-nav__menu-item--active">Battle</button>' : '<button class="n-nav__menu-item" data-go="battle">Battle</button>'}
          ${activeTab === 'practice' ? '<button class="n-nav__menu-item n-nav__menu-item--active">Practice</button>' : '<button class="n-nav__menu-item" data-go="practice">Practice</button>'}
        </div>
        <div class="n-nav__right">
          ${roomCode ? `<span class="n-badge n-badge--amber">${UI.escapeHtml(roomCode)}</span>` : ''}
          ${mode ? `<span class="n-badge n-badge--carbon">${mode === '2v2' ? '2v2' : '1v1'}</span>` : ''}
          <button class="n-nav__audio-toggle" id="btn-audio-toggle" title="Toggle audio">
            <span id="audio-icon">${typeof AudioManager !== 'undefined' && AudioManager.muted ? '🔇' : '🔊'}</span>
          </button>
        </div>
      </nav>
      ${activeTab ? `
        <div class="n-subnav">
          <span class="n-subnav__crumb">Home</span>
          <span class="n-subnav__sep">›</span>
          <span class="n-subnav__crumb">${UI.escapeHtml(activeTab)}</span>
          ${roomCode ? `
            <span class="n-subnav__sep">›</span>
            <span class="n-subnav__current">${UI.escapeHtml(roomCode)}</span>
          ` : ''}
        </div>
      ` : ''}
    `;
  },

  /**
   * Render daftar room yang tersedia (untuk lobby).
   * Auto-detect dari server (broadcast setiap 3 detik).
   */
  roomList(rooms) {
    if (!rooms || rooms.length === 0) {
      return `
        <div class="n-plate n-plate--inset" style="text-align: center; padding: 10px;">
          <div style="font-size: 11px; font-weight: 700; color: var(--c-muted-indigo); text-transform: uppercase; letter-spacing: 0.5px;">
            ⏳ Belum ada room terbuka.<br>
            <span style="font-size: 10px; color: var(--c-muted); font-weight: 400;">Buat room baru di atas, atau minta kode dari teman.</span>
          </div>
        </div>
      `;
    }
    return rooms.map(r => {
      const isLocked = r.status === 'playing' || r.isFull;
      const opacityStyle = isLocked ? 'opacity: 0.6; filter: grayscale(1);' : '';
      return `
        <article class="n-castle" data-room-code="${UI.escapeHtml(r.code)}" style="padding: 6px 10px; ${opacityStyle}">
          <div class="n-castle__name">
            <span class="n-badge n-badge--amber">${UI.escapeHtml(r.code)}</span>
            <span class="n-badge n-badge--carbon">${r.mode === '2v2' ? '2v2' : '1v1'}</span>
            <span class="n-badge n-badge--carbon">${UI.escapeHtml((r.level || 'n5').toUpperCase())}</span>
            ${r.status === 'playing' ? '<span class="n-badge n-badge--red" style="animation: n-timer-warning 1s infinite alternate;">⚔️ Bertanding</span>' : (r.isFull ? '<span class="n-badge n-badge--carbon">Penuh</span>' : '<span class="n-badge n-badge--shield">Menunggu</span>')}
          </div>
          <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 4px; gap: 8px;">
            <span style="font-size: 10px; color: var(--c-ink-soft); font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px;">
              👑 ${UI.escapeHtml(r.hostName)} · ${r.players}/${r.capacity} pemain
            </span>
            <button type="button" class="n-btn n-btn--primary" data-join-room="${UI.escapeHtml(r.code)}" style="font-size: 10px; padding: 4px 10px; min-height: 28px;" ${isLocked ? 'disabled' : ''}>
              ${r.status === 'playing' ? 'BERJALAN' : (r.isFull ? 'PENUH' : '▶ JOIN')}
            </button>
          </div>
        </article>
      `;
    }).join('');
  },


  // ════════════════════════════════════════════════════════════
  // Lobby — Logo Pill + Hero Panel + Form Panels
  // ════════════════════════════════════════════════════════════
  lobby(state) {
    const selectedMode = state?.selectedMode || '1v1';
    return `
      ${this.topNav({ activeTab: 'lobby' })}
      <div class="n-page">
        <div class="n-page__inner">
          <div class="n-hero">
            <div class="n-hero__display">DUEL<br>START</div>
            <div class="n-hero__tagline">
              ⚔️ Tes kecepatan & ketepatanmu ⚔️<br>
              Bom meledak setiap 6 detik!
            </div>
            <div class="n-hero__cta">
              <span class="n-badge n-badge--amber">v2.0 Mobile</span>
              <span class="n-badge n-badge--carbon">Multiplayer</span>
            </div>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Profil Player</span>
          </div>
          <div class="n-plate" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
            <div>
              <div style="font-size: 10px; font-weight: 700; color: var(--n-ink-soft); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px;">Username Aktif</div>
              <div style="font-size: 15px; font-weight: 900; color: var(--n-carbon);">${UI.escapeHtml(state.username || 'Belum diset')}</div>
            </div>
            <button class="n-btn n-btn--secondary" id="btn-edit-username" style="font-size: 10px; padding: 6px 12px; min-height: 28px;">UBAH</button>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Papan Peringkat (Leaderboard)</span>
          </div>
          <div class="n-plate" style="text-align: center; margin-bottom: 12px; padding: 12px;">
            <button class="n-btn n-btn--amber n-btn--block" id="btn-show-leaderboard" style="font-weight: 900; letter-spacing: 1px;">
              🏆 LIHAT LEADERBOARD 🏆
            </button>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Deck Kanji Kamu</span>
          </div>
          <div class="n-plate" style="margin-bottom: 12px; text-align: center; padding: 12px;">
            <div>
              <button class="n-btn n-btn--amber n-btn--block" id="btn-view-deck" style="font-weight: 900; letter-spacing: 0.6px;">
                📚 LIHAT DECK
              </button>
            </div>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Komunitas</span>
          </div>
          <div class="n-plate" style="text-align: center; margin-bottom: 12px; padding: 12px;">
            <a href="https://whatsapp.com/channel/0029Vb7hzsdDzgTKCVpmJI0Y" target="_blank" style="text-decoration: none;">
              <button class="n-btn n-btn--block" style="font-weight: 900; letter-spacing: 1px; background: #25D366; color: white; border-color: #128C7E; border-bottom: 2px solid #075E54; box-shadow: none;">
                🌟 JOIN KOMUNITAS IKUZE JAPAN
              </button>
            </a>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Quick Match — Pilih Mode</span>
          </div>

          <div class="n-plate">
            <div class="n-field">
              <label class="n-field__label">≡ Level Kanji</label>
              <select id="create-level" class="n-field__input">
                <option value="n5" ${state.selectedLevel === 'n5' ? 'selected' : ''}>N5 (Pemula)</option>
                <option value="n4" ${state.selectedLevel === 'n4' ? 'selected' : ''}>N4 (Dasar)</option>
                <option value="n3" ${state.selectedLevel === 'n3' ? 'selected' : ''}>N3 (Menengah)</option>
                <option value="n2" ${state.selectedLevel === 'n2' ? 'selected' : ''}>N2 (Mahir)</option>
                <option value="n1" ${state.selectedLevel === 'n1' ? 'selected' : ''}>N1 (Fasih)</option>
              </select>
            </div>

            <div class="n-field">
              <label class="n-field__label">≡ Mode Pertandingan</label>
              <div style="display: flex; gap: 4px; padding: 4px 0;">
                <button type="button" class="n-answer__btn ${selectedMode === '1v1' ? 'n-answer__btn--selected' : ''}" data-mode="1v1" id="mode-1v1" style="flex: 1;">
                  <span class="n-answer__btn-letter">A</span>
                  <span class="n-answer__btn-text">1 vs 1</span>
                </button>
                <button type="button" class="n-answer__btn ${selectedMode === '2v2' ? 'n-answer__btn--selected' : ''}" data-mode="2v2" id="mode-2v2" style="flex: 1;">
                  <span class="n-answer__btn-letter">B</span>
                  <span class="n-answer__btn-text">2 vs 2</span>
                </button>
              </div>
            </div>

            <button id="btn-create" class="n-btn n-btn--submit n-btn--block n-btn--large">
              ▶ BUAT ROOM
            </button>
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Room Tersedia — Auto-detect</span>
            <span class="n-section-bar__action" id="room-list-count">0</span>
          </div>
          <div class="n-stack" id="room-list" style="margin-bottom: 10px;">
            ${this.roomList(state.availableRooms || [])}
          </div>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Join Room Teman (input kode)</span>
          </div>

          <div class="n-plate">
            <div class="n-field">
              <label class="n-field__label" for="join-code">≡ Kode Room</label>
              <input id="join-code" value="${state.pendingJoinRoom || ''}" class="n-field__input" type="text" placeholder="ABCD12" maxlength="6" autocomplete="off" style="text-transform: uppercase; font-family: monospace; letter-spacing: 4px; text-align: center;" />
            </div>
            <button id="btn-join" class="n-btn n-btn--primary n-btn--block">
              ▶ JOIN
            </button>
          </div>
        </div>

        ${this.footer()}
      </div>
    `;
  },

  // ════════════════════════════════════════════════════════════
  // Room (Waiting) — Player slots dengan chrome plates
  // ════════════════════════════════════════════════════════════
  room(state) {
    const me = state.players.find((p) => p.id === Client.socket?.id);
    const isHost = !!me?.host;
    const team1 = state.players.filter((p) => p.team === 1);
    const team2 = state.players.filter((p) => p.team === 2);

    return `
      ${this.topNav({ activeTab: 'room', roomCode: state.code, mode: state.mode })}
      <div class="n-page">
        <div class="n-page__inner">
          <h1 class="n-page__title">≡ Room ${UI.escapeHtml(state.code)}</h1>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Status Room</span>
            <span class="n-section-bar__action">${state.players.length}/${state.capacity}</span>
          </div>

          <div class="n-plate">
            <p style="margin-bottom: 8px; font-size: 11px; font-weight: 700; color: var(--n-ink-soft); text-transform: uppercase; letter-spacing: 0.5px;">
              ${this.roomStatusText(state)}
            </p>

            <div class="n-section-bar" style="margin-bottom: 6px;">
              <span class="n-section-bar__text">Tim 1</span>
            </div>
            <div class="n-stack" style="margin-bottom: 10px;">
              ${team1.length === 0 ? this.emptySlot() : team1.map((p) => this.playerSlot(p, state, p.id === me?.id, isHost)).join('')}
            </div>

            <div class="n-section-bar" style="margin-bottom: 6px;">
              <span class="n-section-bar__text">Tim 2</span>
            </div>
            <div class="n-stack" style="margin-bottom: 10px;">
              ${team2.length === 0 ? this.emptySlot() : team2.map((p) => this.playerSlot(p, state, p.id === me?.id, isHost)).join('')}
            </div>
          </div>

          <div class="n-plate" style="text-align: center;">
            ${
              isHost
                ? `<button class="n-btn n-btn--submit n-btn--block n-btn--large" id="btn-start" ${state.canStart ? '' : 'disabled'}>
                    ${state.canStart ? '🚀 MULAI PERTANDINGAN!' : '⏳ ' + (state.players.length < state.capacity ? `Menunggu ${state.capacity - state.players.length} pemain lagi...` : 'Menunggu semua siap...')}
                  </button>`
                : `<button class="n-btn n-btn--primary n-btn--block n-btn--large" id="btn-ready">
                    ${me?.ready ? '↩ BATAL SIAP' : '✓ SAYA SIAP'}
                  </button>`
            }
            <button class="n-btn n-btn--secondary n-btn--block" id="btn-leave" style="margin-top: 6px;">
              ⬅ Keluar Room
            </button>
            ${state.mode === '2v2' && !me?.ready && !me?.host ? `
            <button class="n-btn n-btn--block" id="btn-switch-team" style="margin-top: 6px; background: var(--n-chrome-indigo); color: white; border-color: #2a376c;">
              🔄 Pindah Tim
            </button>
            ` : ''}
            <button class="n-btn n-btn--amber n-btn--block" id="btn-share-wa" style="margin-top: 6px; font-weight: 900; background: #25D366; color: white; border-color: #128C7E; border-bottom: 2px solid #075E54; box-shadow: none;">
              📱 Bagikan ke WhatsApp
            </button>
          </div>

          <!-- Chat Room Section -->
          <div class="n-section-bar" style="margin-top: 16px;">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Chat Room</span>
          </div>
          <div class="n-plate" style="display: flex; flex-direction: column; gap: 8px;">
            <div id="chat-messages" style="height: 140px; overflow-y: auto; background: var(--n-canvas-soft, #9fbee7); padding: 8px; border: 1px solid var(--n-chrome-indigo, #3d4f97); border-radius: var(--n-r-xs); display: flex; flex-direction: column; gap: 4px; box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);">
              ${(state.chats || []).length === 0 ? '<div style="font-size: 10px; opacity: 0.6; text-align: center; margin-top: auto; margin-bottom: auto; color: var(--n-carbon);">Belum ada pesan.</div>' : ''}
              ${(state.chats || []).map(c => `
                <div style="font-size: 12px; line-height: 1.3; background: ${c.isMe ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.4)'}; padding: 4px 6px; border-radius: 4px; align-self: ${c.isMe ? 'flex-end' : 'flex-start'}; max-width: 90%; word-wrap: break-word;">
                  <strong style="color: ${c.isMe ? 'var(--n-primary)' : 'var(--n-carbon)'}; font-size: 10px;">${UI.escapeHtml(c.name)}:</strong>
                  <div style="color: var(--n-carbon); margin-top: 2px;">${UI.escapeHtml(c.text)}</div>
                </div>
              `).join('')}
            </div>
            <div style="display: flex; gap: 6px;">
              <input type="text" id="chat-input" class="n-field__input" placeholder="Ketik pesan..." maxlength="100" autocomplete="off" style="flex: 1; height: 36px; min-height: 36px; border-radius: var(--n-r-xs);" />
              <button id="btn-send-chat" class="n-btn n-btn--primary" style="height: 36px; min-height: 36px; padding: 0 16px;">KIRIM</button>
            </div>
          </div>
        </div>
        ${this.footer()}
      </div>
    `;
  },

  roomStatusText(state) {
    const need = state.capacity - state.players.length;
    if (need > 0) return `⏳ Menunggu ${need} pemain lagi...`;
    if (!state.canStart) {
      const waiting = state.players.filter((p) => !p.host && !p.ready);
      if (waiting.length > 0) {
        return `⏳ Menunggu ${waiting.map((p) => p.name).join(', ')} siap...`;
      }
    }
    return '✅ Siap dimulai!';
  },

  leaderboardBadges(badges = []) {
    if (!Array.isArray(badges) || badges.length === 0) return '';

    const getStyle = (badge) => {
      const rank = Number(badge.rank) || 99;
      const board = badge.board;

      if (rank === 1) {
        return board === 'daily'
          ? 'background:#f4cf57;color:#3b2600;border-color:#9b6a00;'
          : 'background:#fff0a8;color:#2f4071;border-color:#7188bd;';
      }
      if (rank === 2) {
        return board === 'daily'
          ? 'background:#d8dee8;color:#21324d;border-color:#7d8da7;'
          : 'background:#dce7ff;color:#263d68;border-color:#8093ba;';
      }
      if (rank === 3) {
        return board === 'daily'
          ? 'background:#d99c63;color:#3f1f0b;border-color:#8a4b1d;'
          : 'background:#f0c8a3;color:#37517d;border-color:#8f7355;';
      }
      if (rank >= 4 && rank <= 6) {
        return board === 'daily'
          ? 'background:#ffe7a6;color:#6b4700;border-color:#cd9820;'
          : 'background:#dff0ff;color:#1b4968;border-color:#5c97bb;';
      }
      return board === 'daily'
        ? 'background:#fff4cf;color:#715110;border-color:#d8ad44;'
        : 'background:#edf6ff;color:#275173;border-color:#7ba1c0;';
    };

    return `
      <span style="display:inline-flex; align-items:center; gap:4px; flex-wrap:wrap; margin-left:6px; vertical-align:middle;">
        ${badges.map((badge) => `
          <span style="display:inline-flex; align-items:center; justify-content:center; min-height:18px; padding:1px 6px; border:1px solid; border-bottom-width:2px; border-radius:999px; font-size:8px; font-weight:900; letter-spacing:0.45px; text-transform:uppercase; white-space:nowrap; ${getStyle(badge)}">
            ${UI.escapeHtml(badge.label || '')}
          </span>
        `).join('')}
      </span>
    `;
  },

  playerSlot(player, _state, isMe, isViewerHost) {
    let badge = '';
    let statusClass = '';
    let statusText = '';

    if (player.host) {
      badge = '<strong>HOST</strong>';
      statusText = '🛡️ Host';
      statusClass = 'n-badge--amber';
    } else if (player.ready) {
      statusText = '✓ Siap';
      statusClass = 'n-badge--shield';
    } else {
      statusText = '⏳ Belum siap';
      statusClass = 'n-badge--carbon';
    }

    return `
      <div class="n-castle" style="${isMe ? 'border-color: var(--n-signal); border-width: 2px;' : ''}; position: relative;">
        <div class="n-castle__name" style="align-items:flex-start; gap:6px; flex-wrap:wrap;">
          <span style="display:inline-flex; align-items:center; flex-wrap:wrap; gap:4px;">
            <span>${UI.escapeHtml(player.name)}</span>
            ${isMe ? '<span class="n-badge n-badge--carbon">YOU</span>' : ''}
            ${this.leaderboardBadges(player.badges || [])}
          </span>
          ${badge}
        </div>
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px;">
          <span class="n-badge ${statusClass}" style="flex: 0 0 auto;">${statusText}</span>
          ${isViewerHost && !player.host ? `<button class="n-btn n-btn--danger" style="padding: 2px 8px; font-size: 10px; min-height: unset; height: 24px;" data-kick-player="${UI.escapeHtml(player.id)}">KICK</button>` : ''}
        </div>
      </div>
    `;
  },

  emptySlot() {
    return `
      <div class="n-castle" style="opacity: 0.55; background: var(--n-platinum);">
        <div class="n-castle__name">
          <span style="color: var(--n-muted-indigo);">— Slot Kosong —</span>
        </div>
        <div style="font-size: 11px; color: var(--n-muted-indigo); font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">
          ⏳ Menunggu pemain...
        </div>
      </div>
    `;
  },

  // ════════════════════════════════════════════════════════════
  // Battle — Kanji display + Castle panels + Answer buttons
  // ════════════════════════════════════════════════════════════
  battle(state) {
    const team1 = state.players.filter((p) => p.team === 1);
    const team2 = state.players.filter((p) => p.team === 2);

    return `
      ${this.topNav({ activeTab: 'battle', roomCode: state.roomCode, mode: state.mode })}
      <div class="n-page">
        <div class="n-page__inner">

          <div class="n-arena__battle">
            <!-- Tim 1 (kiri) -->
            ${team1.map((p) => this.castlePanel(p, state, 'left')).join('')}

            <!-- Field tengah -->
            <div class="n-arena__field">
              <div class="n-arena__field__label">≡ Soal Ronde ${state.roundNumber}/${state.maxRounds}</div>

              <div class="n-timer" id="battle-timer">5.0</div>

              <div class="n-kanji">${UI.escapeHtml(state.question?.kanji || '?')}</div>

              <div class="n-answer" id="answer-grid">
                ${(state.options || [])
                  .map((opt, i) => this.answerButton(opt, i, state))
                  .join('')}
              </div>

              <div class="n-arena__status">
                ${state.answered ? '✓ Jawaban terkunci' : '⏱ Pilih dalam 6 detik!'}
              </div>

              <button class="n-btn n-btn--secondary" id="btn-leave-battle" style="margin-top: 8px; align-self: center;">
                ⬅ Keluar
              </button>
            </div>

            <!-- Tim 2 (kanan) -->
            ${team2.map((p) => this.castlePanel(p, state, 'right')).join('')}
          </div>

          ${state.lastResult ? this.roundResultModal(state.lastResult, state.players) : ''}
          ${state.matchEnd ? this.matchEndModal(state.matchEnd, state.players) : ''}
        </div>
        ${this.footer()}
      </div>
    `;
  },

  castlePanel(player, state, side) {
    const hp = Math.max(0, player.hp);
    const hpColor = hp > 60 ? 'good' : hp > 30 ? 'warn' : 'danger';
    const isMe = player.id === Client.socket?.id;

    let visualState = '';
    let badge = '';
    if (hp === 0) {
      visualState = 'defeated';
      badge = `<div class="n-castle__badge n-castle__badge--defeated">KO</div>`;
    } else if (state.lastResult?.results) {
      const myResult = state.lastResult.results.find((r) => r.playerId === player.id);
      if (myResult) {
        if (myResult.shielded) {
          visualState = 'shield';
          badge = `<div class="n-castle__badge n-castle__badge--shield">🛡 SHIELD</div>`;
        } else if (!myResult.correct) {
          visualState = 'damage';
          badge = `<div class="n-castle__badge n-castle__badge--damage">💥 −${myResult.damage}</div>`;
        }
      }
    }

    return `
      <div class="n-castle ${isMe ? 'n-castle--me' : ''} ${side === 'right' ? 'n-castle--right' : 'n-castle--left'}" style="${visualState === 'shield' ? 'border-color: var(--n-shield); border-width: 2px;' : ''}${visualState === 'damage' ? 'animation: n-shake 0.5s;' : ''}">
        ${badge}
        <div class="n-castle__name">
          <span>${UI.escapeHtml(player.name)}${isMe ? ' <span class="n-badge n-badge--amber" style="font-size: 8px;">YOU</span>' : ''}${player.host ? ' <strong>HOST</strong>' : ''}</span>
        </div>
        <div class="n-castle__hp">
          <div class="n-castle__hp-bar">
            <div class="n-castle__hp-fill n-castle__hp-fill--${hpColor}" style="width: ${hp}%;"></div>
          </div>
          <div class="n-castle__hp-label">${hp}/100</div>
        </div>
      </div>
    `;
  },

  answerButton(opt, index, state) {
    let cls = 'n-answer__btn';
    if (state.selectedAnswer === opt) cls += ' n-answer__btn--selected';
    if (state.lastResult?.correctAnswer) {
      if (opt === state.lastResult.correctAnswer) cls += ' n-answer__btn--correct';
      else if (opt === state.selectedAnswer) cls += ' n-answer__btn--wrong';
    }
    const disabled = state.answered || state.lastResult ? 'disabled' : '';
    const letter = String.fromCharCode(65 + index);
    return `
      <button class="${cls}" data-answer="${UI.escapeHtml(opt)}" ${disabled}>
        <span class="n-answer__btn-letter">${letter}</span>
        <span class="n-answer__btn-text">${UI.escapeHtml(opt)}</span>
        <span style="font-size: 14px; color: var(--n-chrome-indigo);">▶</span>
      </button>
    `;
  },

  // ════════════════════════════════════════════════════════════
  // Modal — Carbon header dengan chrome-indigo bevel
  // ════════════════════════════════════════════════════════════
  roundResultModal(result, players) {
    if (!result || !result.results) return '';
    return `
      <div class="n-modal-backdrop">
        <div class="n-modal" id="round-result-modal">
          <div class="n-modal__header">
            <span>≡ Ronde ${result.roundNumber} Selesai</span>
          </div>
          <div class="n-modal__body">
            <p style="text-align: center; margin-bottom: 12px; padding: 8px; background: var(--n-amber); color: var(--n-carbon); border: 1px solid var(--n-nav-gold); font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; font-size: 11px;">
              ⭐ Jawaban benar: <strong style="font-size: 13px;">${UI.escapeHtml(result.correctAnswer)}</strong>
            </p>
            <div class="n-stack">
              ${result.results.map((res) => `
                <div class="n-castle" style="padding: 6px;">
                  <div class="n-castle__name">
                    <span>${UI.escapeHtml(res.name)}</span>
                    <span class="n-badge ${res.shielded ? 'n-badge--shield' : 'n-badge--red'}">${res.shielded ? '🛡 SHIELD' : `−${res.damage} HP`}</span>
                  </div>
                  <div style="font-size: 11px; color: var(--n-ink-soft); font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px;">
                    ${res.correct ? '✓ BENAR' : res.submitted ? '✗ SALAH' : '⏱ TIDAK JAWAB'} · Tim ${res.team}
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="n-modal__actions">
            <button class="n-btn n-btn--primary" disabled>⏳ 3 detik...</button>
          </div>
        </div>
      </div>
    `;
  },

  matchEndModal(end, players) {
    if (!end || !players || !Array.isArray(players)) return '';
    const me = players.find((p) => p.id === Client.socket?.id);

    let title, subtitle, winColor;
    if (end.winner === 'draw') {
      title = '⚖️ SERI!';
      subtitle = 'Tidak ada pemenang.';
      winColor = 'var(--n-amber)';
    } else if (me?.team === end.winner) {
      title = '🏆 KAMU MENANG!';
      subtitle = `Tim ${end.winner} memenangkan duel.`;
      winColor = 'var(--n-shield)';
    } else {
      title = '💀 KAMU KALAH';
      subtitle = `Tim ${end.winner} memenangkan duel.`;
      winColor = 'var(--n-primary)';
    }

    return `
      <div class="n-modal-backdrop">
        <div class="n-modal" id="match-end-modal">
          <div class="n-modal__header">
            <span>≡ Pertandingan Selesai</span>
          </div>
          <div class="n-modal__body">
            <div style="text-align: center; padding: 16px 8px; background: ${winColor}; color: var(--n-on-primary); border: 1px solid; margin-bottom: 12px;">
              <div style="font-size: 24px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">${title}</div>
              <div style="font-size: 12px; font-weight: 700;">${subtitle}</div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              ${[1, 2].map((team) => {
                const teamPlayers = end.finalPlayers.filter((p) => p.team === team);
                const totalHp = end.totalHp[team];
                const isWinner = end.winner === team;
                return `
                  <div class="n-plate ${isWinner ? '' : ''}" style="padding: 8px; ${isWinner ? 'background: var(--n-shield); color: var(--n-on-primary);' : ''}">
                    <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Tim ${team} ${isWinner ? '🏆' : ''}</div>
                    <div style="font-size: 22px; font-weight: 900; font-variant-numeric: tabular-nums; line-height: 1;">${totalHp} HP</div>
                    <div style="display:grid; gap:6px; margin-top:6px;">
                      ${teamPlayers.map((p) => `
                        <div style="padding:6px; border:1px solid rgba(0,0,0,0.14); background:${isWinner ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.72)'}; color:${isWinner ? 'var(--n-on-primary)' : 'var(--n-carbon)'}; border-radius:6px;">
                          <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:3px;">
                            <span style="font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:0.4px;">${UI.escapeHtml(p.name)}</span>
                            <span class="n-badge ${p.grade === 'S' ? 'n-badge--amber' : p.grade === 'A' ? 'n-badge--shield' : p.grade === 'B' ? 'n-badge--carbon' : 'n-badge--red'}">${UI.escapeHtml(p.grade || 'C')}</span>
                          </div>
                          <div style="font-size:9px; font-weight:700; opacity:0.95; text-transform:uppercase; letter-spacing:0.35px;">
                            ${p.correct || 0} benar · ${p.wrong || 0} salah · ${p.timeout || 0} timeout · ${p.accuracy || 0}%
                          </div>
                        </div>
                      `).join('') || '<div style="font-size:10px; opacity:0.85;">—</div>'}
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>
          <div class="n-modal__actions" style="display: grid; grid-template-columns: 1fr; gap: 8px;">
            <button class="n-btn n-btn--amber" id="btn-save-deck">💾 Simpan ke Deck</button>
            <button class="n-btn n-btn--submit" id="btn-back-room">⬅ Kembali ke Room</button>
          </div>
        </div>
      </div>
    `;
  },

  deck(state) {
    const deck = state.deckData || {};
    const meta = state.deckMeta || {};
    const levels = ['n5', 'n4', 'n3', 'n2', 'n1'];
    const completionBadgeStyle = (info = {}) => {
      const percent = Math.max(0, Math.min(100, Number(info.percent) || 0));
      const badgeKey = info.badge?.key || 'none';
      const fill = badgeKey === 'master'
        ? '#f4cf57'
        : badgeKey === 'gold'
          ? '#e6b43b'
          : badgeKey === 'silver'
            ? '#b9c6db'
            : badgeKey === 'bronze'
              ? '#c88a54'
              : '#8ea1c8';
      const ink = badgeKey === 'silver' || badgeKey === 'none' ? '#24385d' : '#3a2400';
      return `background: linear-gradient(90deg, ${fill} 0%, ${fill} ${percent}%, rgba(255,255,255,0.88) ${percent}%, rgba(255,255,255,0.88) 100%); color:${ink}; border-color: rgba(34,34,34,0.55);`;
    };

    return `
      ${this.topNav({ activeTab: 'practice' })}
      <div class="n-page">
        <div class="n-page__inner">
          <h1 class="n-page__title">≡ Deck Kanji</h1>

          <div class="n-plate" style="margin-bottom: 12px;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <button class="n-btn n-btn--primary n-btn--block" id="btn-practice-menu">🕹 MODE LATIHAN</button>
              <button class="n-btn n-btn--secondary n-btn--block" id="btn-deck-back-lobby">⬅ Kembali ke Lobby</button>
            </div>
          </div>

          ${levels.map((level) => {
            const rows = deck[level] || [];
            const info = meta[level] || { count: rows.length, total: 0, percent: 0, badge: { key: 'none', label: 'NONE' } };
            const badge = info.badge || { key: 'none', label: 'NONE' };
            return `
              <div class="n-section-bar">
                <span class="n-section-bar__glyph"></span>
                <span class="n-section-bar__text">≡ Deck ${level.toUpperCase()}</span>
                <span class="n-section-bar__action">${rows.length}</span>
              </div>
              <div class="n-plate" style="overflow-x: auto; margin-bottom: 12px;">
                <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px dashed rgba(61,79,151,0.4);">
                  <div style="font-size: 11px; font-weight: 700; color: var(--n-carbon); text-transform: uppercase; letter-spacing: 0.45px;">
                    Koleksi ${info.count}/${info.total || 0} · ${info.percent || 0}%
                  </div>
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="font-size: 10px; font-weight: 900; color: var(--n-ink-soft); text-transform: uppercase; letter-spacing: 0.6px;">Badge</span>
                    <span class="n-badge" style="${completionBadgeStyle(info)}">${UI.escapeHtml(badge.label)} · ${UI.escapeHtml(info.percent || 0)}%</span>
                  </div>
                </div>
                ${rows.length === 0 ? `
                  <div style="text-align: center; padding: 14px 10px; font-size: 11px; font-weight: 700; color: var(--n-muted-indigo); text-transform: uppercase; letter-spacing: 0.4px;">
                    Belum ada kanji tersimpan di ${level.toUpperCase()}
                  </div>
                ` : `
                  <table style="width: 100%; border-collapse: collapse; font-size: 11px; min-width: 360px;">
                    <thead>
                      <tr>
                        <th style="text-align: left; padding: 8px 6px; border-bottom: 2px solid var(--n-chrome-indigo);">Kanji</th>
                        <th style="text-align: left; padding: 8px 6px; border-bottom: 2px solid var(--n-chrome-indigo);">Jawaban</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${rows.map((item) => `
                        <tr>
                          <td style="padding: 8px 6px; border-bottom: 1px solid rgba(0,0,0,0.08); font-size: 22px; font-weight: 900; color: var(--n-carbon);">${UI.escapeHtml(item.kanji)}</td>
                          <td style="padding: 8px 6px; border-bottom: 1px solid rgba(0,0,0,0.08); font-weight: 700; color: var(--n-carbon);">${UI.escapeHtml(item.answer)}</td>
                        </tr>
                      `).join('')}
                    </tbody>
                  </table>
                `}
              </div>
            `;
          }).join('')}
        </div>
        ${this.footer()}
      </div>
    `;
  },

  practiceSetup(state) {
    const summary = state.deckSummary || {};
    const selectedLevel = state.practiceConfig?.level || 'n5';
    const selectedTimer = state.practiceConfig?.timerSeconds || 5;
    const levels = ['n5', 'n4', 'n3', 'n2', 'n1'];
    return `
      ${this.topNav({ activeTab: 'practice' })}
      <div class="n-page">
        <div class="n-page__inner">
          <h1 class="n-page__title">≡ Mode Latihan</h1>

          <div class="n-section-bar">
            <span class="n-section-bar__glyph"></span>
            <span class="n-section-bar__text">≡ Pengaturan Latihan</span>
          </div>
          <div class="n-plate" style="margin-bottom: 12px;">
            <div style="font-size: 11px; font-weight: 700; color: var(--n-ink-soft); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px; text-align: center;">
              Pilih level yang sudah punya kanji tersimpan. Level kosong tidak bisa dimainkan.
            </div>

            <div class="n-field">
              <label class="n-field__label">≡ Pilih Level</label>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                ${levels.map((level) => {
                  const count = summary[level] || 0;
                  const disabled = count === 0;
                  return `
                    <button type="button" class="n-answer__btn ${selectedLevel === level ? 'n-answer__btn--selected' : ''}" data-practice-level="${level}" ${disabled ? 'disabled' : ''} style="opacity: ${disabled ? '0.5' : '1'};">
                      <span class="n-answer__btn-letter">${level.toUpperCase()}</span>
                      <span class="n-answer__btn-text">${count} kanji</span>
                    </button>
                  `;
                }).join('')}
              </div>
            </div>

            <div class="n-field">
              <label class="n-field__label">≡ Timer per Soal</label>
              <select id="practice-timer" class="n-field__input">
                ${[5, 6, 7, 8, 9, 10].map((sec) => `<option value="${sec}" ${selectedTimer === sec ? 'selected' : ''}>${sec} detik</option>`).join('')}
              </select>
            </div>

            <div class="n-castle" style="margin-bottom: 10px;">
              <div class="n-castle__name">
                <span>Latihan yang dipilih</span>
                <span class="n-badge n-badge--amber">${selectedLevel.toUpperCase()}</span>
              </div>
              <div style="font-size: 11px; font-weight: 700; color: var(--n-carbon); text-transform: uppercase; letter-spacing: 0.4px;">
                ${summary[selectedLevel] || 0} kanji tersedia · ${selectedTimer} detik per soal · maksimal 10 ronde
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <button class="n-btn n-btn--submit n-btn--block" id="btn-start-practice" ${(summary[selectedLevel] || 0) === 0 ? 'disabled' : ''}>▶ MULAI LATIHAN</button>
              <button class="n-btn n-btn--secondary n-btn--block" id="btn-practice-back-lobby">⬅ Kembali</button>
            </div>
          </div>
        </div>
        ${this.footer()}
      </div>
    `;
  },

  practiceBattle(state) {
    const stats = state.practiceStats || { correct: 0, wrong: 0, timeout: 0 };
    return `
      ${this.topNav({ activeTab: 'practice' })}
      <div class="n-page">
        <div class="n-page__inner">
          <div class="n-arena__battle">
            <div class="n-castle n-castle--left">
              <div class="n-castle__name">
                <span>PROGRESS</span>
                <span class="n-badge n-badge--amber">${state.roundNumber}/${state.maxRounds}</span>
              </div>
              <div style="font-size: 12px; font-weight: 900; color: var(--n-carbon); margin-top: 6px;">Level ${UI.escapeHtml((state.level || 'n5').toUpperCase())}</div>
              <div style="font-size: 11px; color: var(--n-ink-soft); font-weight: 700; margin-top: 4px; text-transform: uppercase;">Timer ${state.timerSeconds} detik</div>
            </div>

            <div class="n-arena__field">
              <div class="n-arena__field__label">≡ Latihan Solo Ronde ${state.roundNumber}/${state.maxRounds}</div>
              <div class="n-timer" id="battle-timer">${state.timerSeconds}.0</div>
              <div class="n-kanji">${UI.escapeHtml(state.question?.kanji || '?')}</div>
              <div class="n-answer" id="answer-grid">
                ${(state.options || []).map((opt, i) => this.answerButton(opt, i, {
                  answered: state.answered,
                  selectedAnswer: state.selectedAnswer,
                  lastResult: state.lastResult,
                })).join('')}
              </div>
              <div class="n-arena__status">
                ${state.answered ? '✓ Jawaban terkunci' : `⏱ Pilih dalam ${state.timerSeconds} detik!`}
              </div>
              <button class="n-btn n-btn--secondary" id="btn-exit-practice" style="margin-top: 8px; align-self: center;">⬅ Keluar Latihan</button>
            </div>

            <div class="n-castle n-castle--right">
              <div class="n-castle__name">
                <span>HASIL</span>
                <span class="n-badge n-badge--shield">SOLO</span>
              </div>
              <div style="display: grid; gap: 6px; margin-top: 6px; font-size: 11px; font-weight: 900; text-transform: uppercase;">
                <div style="display: flex; justify-content: space-between;"><span>Benar</span><span style="color: var(--n-shield);">${stats.correct}</span></div>
                <div style="display: flex; justify-content: space-between;"><span>Salah</span><span style="color: var(--n-primary);">${stats.wrong}</span></div>
                <div style="display: flex; justify-content: space-between;"><span>Timeout</span><span style="color: var(--n-amber);">${stats.timeout}</span></div>
              </div>
            </div>
          </div>

          ${state.lastResult ? this.practiceRoundResultModal(state.lastResult) : ''}
          ${state.practiceEnd ? this.practiceEndModal(state.practiceEnd) : ''}
        </div>
        ${this.footer()}
      </div>
    `;
  },

  practiceRoundResultModal(result) {
    if (!result) return '';
    const badge = result.correct ? 'n-badge--shield' : (result.timedOut ? 'n-badge--amber' : 'n-badge--red');
    const text = result.correct ? '✓ BENAR' : (result.timedOut ? '⏱ WAKTU HABIS' : '✗ SALAH');
    return `
      <div class="n-modal-backdrop">
        <div class="n-modal">
          <div class="n-modal__header">
            <span>≡ Hasil Ronde ${result.roundNumber}</span>
          </div>
          <div class="n-modal__body">
            <div class="n-castle" style="padding: 10px; text-align: center; margin-bottom: 10px;">
              <div class="n-castle__name" style="justify-content: center; margin-bottom: 8px;">
                <span class="n-badge ${badge}">${text}</span>
              </div>
              <div class="n-kanji" style="font-size: 44px; padding: 10px; margin-bottom: 6px;">${UI.escapeHtml(result.kanji)}</div>
              <div style="font-size: 12px; font-weight: 700; color: var(--n-carbon);">Jawaban benar: ${UI.escapeHtml(result.correctAnswer)}</div>
              <div style="font-size: 11px; color: var(--n-ink-soft); margin-top: 6px; font-weight: 700;">${result.selectedAnswer ? `Pilihanmu: ${UI.escapeHtml(result.selectedAnswer)}` : 'Kamu belum menjawab.'}</div>
            </div>
          </div>
          <div class="n-modal__actions">
            <button class="n-btn n-btn--primary" disabled>⏳ Lanjut...</button>
          </div>
        </div>
      </div>
    `;
  },

  practiceEndModal(summary) {
    if (!summary) return '';
    return `
      <div class="n-modal-backdrop">
        <div class="n-modal" id="practice-end-modal">
          <div class="n-modal__header">
            <span>≡ Latihan Selesai</span>
          </div>
          <div class="n-modal__body">
            <div style="text-align: center; padding: 14px 8px; background: var(--n-amber); color: var(--n-carbon); border: 1px solid var(--n-nav-gold); margin-bottom: 12px;">
              <div style="font-size: 22px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">🕹 SOLO PRACTICE CLEAR</div>
              <div style="font-size: 12px; font-weight: 700;">Level ${UI.escapeHtml(summary.level.toUpperCase())} · ${summary.timerSeconds} detik</div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
              <div class="n-plate" style="padding: 8px;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Benar</div>
                <div style="font-size: 24px; font-weight: 900; color: var(--n-shield);">${summary.correct}</div>
              </div>
              <div class="n-plate" style="padding: 8px;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Salah</div>
                <div style="font-size: 24px; font-weight: 900; color: var(--n-primary);">${summary.wrong}</div>
              </div>
              <div class="n-plate" style="padding: 8px;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Timeout</div>
                <div style="font-size: 24px; font-weight: 900; color: var(--n-amber);">${summary.timeout}</div>
              </div>
              <div class="n-plate" style="padding: 8px;">
                <div style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">Akurasi</div>
                <div style="font-size: 24px; font-weight: 900; color: var(--n-carbon);">${summary.accuracy}%</div>
              </div>
            </div>
          </div>
          <div class="n-modal__actions" style="display: grid; grid-template-columns: 1fr; gap: 8px;">
            <button class="n-btn n-btn--submit" id="btn-practice-restart">🔁 Ulangi Latihan</button>
            <button class="n-btn n-btn--amber" id="btn-practice-settings">⚙ Ganti Setting</button>
            <button class="n-btn n-btn--secondary" id="btn-practice-finish-lobby">⬅ Kembali ke Lobby</button>
          </div>
        </div>
      </div>
    `;
  },

  rewardFlash(flash) {
    if (!flash) return '';
    return `
      <div class="n-modal-backdrop" style="z-index: 9998; background: rgba(11, 20, 54, 0.74); pointer-events: none;">
        <div class="n-modal" style="max-width: 320px; border-width: 3px; box-shadow: 0 0 0 3px rgba(255,255,255,0.12), 0 12px 34px rgba(0,0,0,0.35);">
          <div class="n-modal__header" style="justify-content: center; text-align: center;">
            <span>≡ KOLEKSI BARU</span>
          </div>
          <div class="n-modal__body" style="text-align: center; padding-top: 18px; padding-bottom: 18px;">
            <div style="font-size: 28px; font-weight: 900; color: var(--n-amber); text-transform: uppercase; letter-spacing: 1px; line-height: 1.1; text-shadow: 2px 2px 0 rgba(0,0,0,0.14); margin-bottom: 8px;">
              ${UI.escapeHtml(flash.title || 'NEW KANJI!')}
            </div>
            ${flash.subtitle ? `<div style="font-size: 12px; font-weight: 900; color: var(--n-chrome-indigo); text-transform: uppercase; letter-spacing: 0.7px; margin-bottom: 6px;">${UI.escapeHtml(flash.subtitle)}</div>` : ''}
            ${flash.note ? `<div style="font-size: 10px; font-weight: 700; color: var(--n-ink-soft); text-transform: uppercase; letter-spacing: 0.45px;">${UI.escapeHtml(flash.note)}</div>` : ''}
          </div>
        </div>
      </div>
    `;
  },

  usernameModal() {
    return `
      <div class="n-modal-backdrop" id="username-modal-backdrop" style="z-index: 9999;">
        <div class="n-modal">
          <div class="n-modal__header">
            <span>≡ Set Username</span>
          </div>
          <div class="n-modal__body">
            <p style="font-size: 12px; margin-bottom: 8px;">Silakan masukkan username kamu sebelum bermain.</p>
            <input id="global-username-input" class="n-field__input" type="text" placeholder="Nama Kamu" maxlength="20" autocomplete="off" />
          </div>
          <div class="n-modal__actions">
            <button class="n-btn n-btn--submit n-btn--block" id="btn-save-username">Simpan</button>
          </div>
        </div>
      </div>
    `;
  },

  leaderboardModal(data) {
    if (!data) return '';
    const daily = data.daily || [];
    const weekly = data.weekly || [];

    const renderList = (list) => {
      if (list.length === 0) return `<div style="text-align: center; font-size: 11px; opacity: 0.6; padding: 12px;">Belum ada data</div>`;
      return list.map((item, idx) => `
        <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px 4px; border-bottom: 1px solid rgba(0,0,0,0.05); ${idx < 3 ? 'background: linear-gradient(to right, rgba(255,215,0,0.1) 0%, transparent 100%); border-radius: 4px;' : ''}">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-weight: 900; font-size: ${idx === 0 ? '18px' : idx === 1 ? '16px' : idx === 2 ? '14px' : '12px'}; color: ${idx === 0 ? '#e48600' : idx === 1 ? '#8ba1d4' : idx === 2 ? '#d27315' : 'var(--n-carbon)'}; width: 24px; text-shadow: ${idx < 3 ? '1px 1px 0px rgba(0,0,0,0.1)' : 'none'};">
              ${idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`}
            </span>
            <span style="font-weight: ${idx < 3 ? '900' : '700'}; font-size: ${idx < 3 ? '14px' : '12px'}; color: var(--n-carbon);">${UI.escapeHtml(item.name)}</span>
          </div>
          <div style="font-weight: 900; font-size: ${idx < 3 ? '14px' : '12px'}; color: var(--n-primary);">${item.score} <span style="font-size: 9px; color: var(--n-ink-soft);">PTS</span></div>
        </div>
      `).join('');
    };

    return `
      <div class="n-modal-backdrop" id="leaderboard-modal-backdrop" style="z-index: 9999;">
        <div class="n-modal" style="max-height: 80vh; display: flex; flex-direction: column;">
          <div class="n-modal__header" style="display: flex; justify-content: space-between; align-items: center;">
            <span>≡ Leaderboard Global</span>
            <button id="btn-close-leaderboard" style="background: var(--n-primary); border: 1px solid var(--n-carbon); border-radius: 4px; color: white; font-weight: 900; font-size: 16px; cursor: pointer; padding: 0 8px; line-height: 1; height: 24px; display: flex; align-items: center; justify-content: center; transform: translateY(-2px);">×</button>
          </div>
          <div class="n-modal__body" style="flex: 1; overflow-y: auto; padding: 12px;">
            <div style="margin-bottom: 16px;">
              <h3 style="font-size: 14px; font-weight: 900; color: var(--n-chrome-indigo); margin-bottom: 8px; border-bottom: 2px solid var(--n-chrome-indigo); padding-bottom: 4px; text-transform: uppercase;">🔥 Daily Top 10</h3>
              <div style="background: white; border-radius: 4px; padding: 8px; box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);">
                ${renderList(daily)}
              </div>
            </div>
            <div>
              <h3 style="font-size: 14px; font-weight: 900; color: var(--n-signal); margin-bottom: 8px; border-bottom: 2px solid var(--n-signal); padding-bottom: 4px; text-transform: uppercase;">🌟 Weekly Top 10</h3>
              <div style="background: white; border-radius: 4px; padding: 8px; box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);">
                ${renderList(weekly)}
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  confirmDialog(opts) {
    if (!opts) return '';
    const { title, message, confirmText = 'Ya', cancelText = 'Batal', danger = false } = opts;
    return `
      <div class="n-modal-backdrop">
        <div class="n-modal">
          <div class="n-modal__header">
            <span>≡ ${UI.escapeHtml(title)}</span>
          </div>
          <div class="n-modal__body">
            <p style="font-size: 12px; line-height: 1.5;">${UI.escapeHtml(message)}</p>
          </div>
          <div class="n-modal__actions">
            <button class="n-btn n-btn--secondary" id="btn-confirm-cancel">${UI.escapeHtml(cancelText)}</button>
            <button class="n-btn ${danger ? 'n-btn--danger' : 'n-btn--submit'}" id="btn-confirm-ok">${UI.escapeHtml(confirmText)}</button>
          </div>
        </div>
      </div>
    `;
  },

  // ════════════════════════════════════════════════════════════
  // Footer (Carbon dengan ESRB badge)
  // ════════════════════════════════════════════════════════════
  footer() {
    return `
      <footer class="n-footer" style="margin-top: auto; height: auto; min-height: unset; padding: 32px 16px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; text-align: center; box-sizing: border-box; background: var(--n-carbon, #21242e); border-top: 2px solid var(--n-nav-gold, #cfb078);">
        <h2 style="font-size: 28px; font-weight: 900; color: var(--n-surface, #ffffff); letter-spacing: 4px; margin: 0 0 4px 0; opacity: 0.95;">
          IKUZE JAPAN
        </h2>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; align-items: center; gap: 8px; font-size: 11px; font-weight: 700; color: var(--n-platinum, #dedede); opacity: 0.55; line-height: 1.4; text-transform: uppercase;">
          <span>© 2026 Kanji Duel</span>
          <span>&bull;</span>
          <span>Multiplayer Quiz Battle</span>
        </div>
      </footer>
    `;
  },
};

// Add shake animation for damage (used in castlePanel)
if (typeof document !== 'undefined') {
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    @keyframes n-shake {
      0%, 100% { transform: translateX(0); }
      20% { transform: translateX(-4px); }
      40% { transform: translateX(4px); }
      60% { transform: translateX(-3px); }
      80% { transform: translateX(3px); }
    }
    .n-castle--shield { border-color: var(--n-shield); border-width: 2px; animation: n-shield-glow 1.5s infinite; }
    @keyframes n-shield-glow {
      0%, 100% { box-shadow: 0 0 4px var(--n-shield); }
      50% { box-shadow: 0 0 12px var(--n-shield); }
    }
  `;
  document.head.appendChild(styleEl);
}
