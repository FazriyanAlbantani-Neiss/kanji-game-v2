/**
 * client.js — Main SPA controller (Nintendo 2001 chrome style)
 *
 * Integrasi:
 *  - Socket.IO real-time
 *  - Audio Manager (BGM per view, SFX per event)
 *  - Event delegation untuk click handler (anti re-render issue)
 *  - Deck Kanji + Mode Latihan single-player
 *  - Optimized untuk Android (touch, compact)
 */

// URL Backend (kosong = same origin). Isi bila frontend dipisah dari server.
const BACKEND_URL = '';

const Client = {
  socket: null,
  timerInterval: null,
  practiceAdvanceTimeout: null,
  rewardFlashTimeout: null,
  lastViewBGM: null,

  state: {
    username: null,
    secretId: null,
    view: 'lobby',
    selectedMode: '1v1',
    selectedLevel: 'n5',

    roomCode: null,
    roomMode: null,
    roomLevel: 'n5',
    roomPlayers: [],
    roomCanStart: false,
    roomChats: [],

    battleMode: null,
    battlePlayers: [],
    roundNumber: 1,
    maxRounds: 10,
    question: null,
    options: [],
    endsAt: null,
    answered: false,
    selectedAnswer: null,
    lastResult: null,
    matchEnd: null,

    pendingConfirm: null,
    availableRooms: [],

    deckSummary: { n5: 0, n4: 0, n3: 0, n2: 0, n1: 0 },
    deckMeta: {},
    deckData: { n5: [], n4: [], n3: [], n2: [], n1: [] },
    deckLoaded: false,
    deckLoading: false,
    rewardFlash: null,

    practiceConfig: {
      level: 'n5',
      timerSeconds: 5,
    },
    practiceSession: null,
  },

  init() {
    this.state.username = localStorage.getItem('kanji-username') || null;

    let sId = localStorage.getItem('kanji-secret-id');
    if (!sId) {
      sId = 'USR_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
      localStorage.setItem('kanji-secret-id', sId);
    }
    this.state.secretId = sId;

    const urlParams = new URLSearchParams(window.location.search);
    const roomFromUrl = urlParams.get('room');
    if (roomFromUrl) {
      this.state.pendingJoinRoom = roomFromUrl.toUpperCase();
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    if (typeof AudioManager !== 'undefined') AudioManager.init();

    let ioUrl = BACKEND_URL || window.location.origin;
    if (ioUrl.endsWith('/')) ioUrl = ioUrl.slice(0, -1);

    this.socket = io(ioUrl, {
      path: '/socket.io',
      transports: ['websocket', 'polling'],
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      secure: ioUrl.startsWith('https://'),
    });

    this.bindSocketEvents();
    this.bindGlobalEvents();
    this.render();
    this.refreshDeckSummary();

    console.log('[KanjiDuel] client initialized, menembak ke:', ioUrl);
  },

  apiBaseUrl() {
    let base = BACKEND_URL || window.location.origin;
    if (base.endsWith('/')) base = base.slice(0, -1);
    return base;
  },

  fetchJson(path) {
    return fetch(this.apiBaseUrl() + path).then(async (res) => {
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || 'Request gagal');
      return data;
    });
  },

  emptyDeck() {
    return { n5: [], n4: [], n3: [], n2: [], n1: [] };
  },

  emptyDeckMeta() {
    return {
      n5: { count: 0, total: 0, percent: 0, badge: { key: 'none', label: 'NONE', tier: 0 } },
      n4: { count: 0, total: 0, percent: 0, badge: { key: 'none', label: 'NONE', tier: 0 } },
      n3: { count: 0, total: 0, percent: 0, badge: { key: 'none', label: 'NONE', tier: 0 } },
      n2: { count: 0, total: 0, percent: 0, badge: { key: 'none', label: 'NONE', tier: 0 } },
      n1: { count: 0, total: 0, percent: 0, badge: { key: 'none', label: 'NONE', tier: 0 } },
    };
  },

  syncDeckCaches(summary, deck, meta) {
    if (summary) {
      this.state.deckSummary = {
        n5: summary.n5 || 0,
        n4: summary.n4 || 0,
        n3: summary.n3 || 0,
        n2: summary.n2 || 0,
        n1: summary.n1 || 0,
      };
    }

    if (meta && typeof meta === 'object') {
      const baseMeta = this.emptyDeckMeta();
      ['n5', 'n4', 'n3', 'n2', 'n1'].forEach((level) => {
        if (meta[level]) {
          baseMeta[level] = {
            count: Number(meta[level].count) || 0,
            total: Number(meta[level].total) || 0,
            percent: Number(meta[level].percent) || 0,
            badge: meta[level].badge || { key: 'none', label: 'NONE', tier: 0 },
          };
        }
      });
      this.state.deckMeta = baseMeta;
    }

    if (deck) {
      this.state.deckData = {
        n5: Array.isArray(deck.n5) ? deck.n5 : [],
        n4: Array.isArray(deck.n4) ? deck.n4 : [],
        n3: Array.isArray(deck.n3) ? deck.n3 : [],
        n2: Array.isArray(deck.n2) ? deck.n2 : [],
        n1: Array.isArray(deck.n1) ? deck.n1 : [],
      };
      this.state.deckLoaded = true;
    }
  },

  refreshDeckSummary(force = false) {
    if (!this.state.secretId) return Promise.resolve(this.state.deckSummary);
    if (this.state.deckLoading && !force) return Promise.resolve(this.state.deckSummary);

    this.state.deckLoading = true;
    return this.fetchJson(`/api/deck/${encodeURIComponent(this.state.secretId)}/summary`)
      .then((data) => {
        this.syncDeckCaches(data.summary, null, data.meta);
        if (this.state.view === 'lobby') this.renderLobby();
        if (this.state.view === 'deck') this.renderDeck();
        if (this.state.view === 'practiceSetup') this.renderPracticeSetup();
        return this.state.deckSummary;
      })
      .catch((err) => {
        console.error('[deck] summary error', err);
        return this.state.deckSummary;
      })
      .finally(() => {
        this.state.deckLoading = false;
      });
  },

  loadDeckData(force = false) {
    if (!this.state.secretId) return Promise.resolve(this.state.deckData);
    if (this.state.deckLoaded && !force) return Promise.resolve(this.state.deckData);

    this.state.deckLoading = true;
    return this.fetchJson(`/api/deck/${encodeURIComponent(this.state.secretId)}`)
      .then((data) => {
        this.syncDeckCaches(data.summary, data.deck || this.emptyDeck(), data.meta);
        return this.state.deckData;
      })
      .catch((err) => {
        console.error('[deck] load error', err);
        UI.toast('Gagal memuat deck kanji', { variant: 'error' });
        return this.state.deckData;
      })
      .finally(() => {
        this.state.deckLoading = false;
      });
  },

  defaultPracticeLevel() {
    const summary = this.state.deckSummary || {};
    return ['n5', 'n4', 'n3', 'n2', 'n1'].find((level) => (summary[level] || 0) > 0) || 'n5';
  },

  shuffleArray(arr) {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  },

  clearRewardFlash() {
    if (this.rewardFlashTimeout) {
      clearTimeout(this.rewardFlashTimeout);
      this.rewardFlashTimeout = null;
    }
    this.state.rewardFlash = null;
  },

  flashReward(payload) {
    this.clearRewardFlash();
    this.state.rewardFlash = payload;
    if (typeof AudioManager !== 'undefined') AudioManager.sfx('victory');
    this.render();
    this.rewardFlashTimeout = setTimeout(() => {
      this.state.rewardFlash = null;
      this.rewardFlashTimeout = null;
      this.render();
    }, 1800);
  },

  bindSocketEvents() {
    const safe = (label, fn) => (data) => {
      try { fn(data); }
      catch (err) {
        console.error(`[KanjiDuel] error in ${label}:`, err);
        UI.toast('Error, coba refresh', { variant: 'error' });
      }
    };

    this.socket.on('room:update', safe('room:update', (state) => {
      if (state.code === this.state.roomCode) {
        this.state.roomPlayers = state.players;
        this.state.roomCanStart = state.canStart;
        this.state.roomMode = state.mode;
        this.state.roomLevel = state.level || this.state.roomLevel;
        if (this.state.view === 'room') this.renderRoom();
      }
    }));

    this.socket.on('room:list', safe('room:list', (list) => {
      this.state.availableRooms = list || [];
      if (this.state.view === 'lobby') {
        const container = document.getElementById('room-list');
        if (container) container.innerHTML = Views.roomList(this.state.availableRooms);
        const counter = document.getElementById('room-list-count');
        if (counter) counter.textContent = this.state.availableRooms.length;
      }
    }));

    this.socket.on('round:start', safe('round:start', (data) => {
      this.clearPracticeAdvance();
      this.state.view = 'battle';
      this.state.battleMode = data.mode;
      this.state.battlePlayers = data.players;
      this.state.roundNumber = data.roundNumber;
      this.state.maxRounds = data.maxRounds;
      this.state.question = data.question;
      this.state.options = data.options;
      this.state.endsAt = data.endsAt;
      this.state.answered = false;
      this.state.selectedAnswer = null;
      this.state.lastResult = null;
      this.state.matchEnd = null;

      this.renderBattle();
      this.startTimer(data.endsAt);
    }));

    this.socket.on('round:result', safe('round:result', (data) => {
      this.stopTimer();
      this.state.lastResult = data;
      this.state.battlePlayers = data.players;
      this.state.answered = true;
      this.renderBattle();

      const myResult = data.results.find((r) => r.playerId === Client.socket?.id);
      if (myResult && typeof AudioManager !== 'undefined') {
        if (myResult.shielded) AudioManager.sfx('shield');
        else if (!myResult.correct) AudioManager.sfx('wrong');
        else AudioManager.sfx('correct');
      }
    }));

    this.socket.on('match:end', safe('match:end', (data) => {
      this.stopTimer();
      this.state.matchEnd = data;
      this.state.battlePlayers = data.finalPlayers;
      this.renderBattle();

      if (typeof AudioManager !== 'undefined') {
        const me = data.finalPlayers.find((p) => p.id === Client.socket?.id);
        if (data.winner === 'draw') {
          AudioManager.bgm('lobby');
          AudioManager.sfx('defeat');
        } else if (me?.team === data.winner) {
          AudioManager.bgm('victory');
          AudioManager.sfx('victory');
        } else {
          AudioManager.bgm('defeat');
          AudioManager.sfx('defeat');
        }
      }
    }));

    this.socket.on('error', (data) => {
      if (typeof AudioManager !== 'undefined') AudioManager.sfx('wrong');
      UI.toast(data.message || 'Terjadi kesalahan', { variant: 'error' });
    });

    this.socket.on('room:chat', safe('room:chat', (msg) => {
      if (this.state.view === 'room') {
        msg.isMe = (msg.playerId === Client.socket?.id);
        this.state.roomChats.push(msg);
        this.renderRoom();
        setTimeout(() => {
          const container = document.getElementById('chat-messages');
          if (container) container.scrollTop = container.scrollHeight;
        }, 50);
      }
    }));

    this.socket.on('room:kicked', () => {
      UI.toast('Kamu telah dikeluarkan oleh Host.', { variant: 'error' });
      this.socket.emit('room:leave', {});
      this.resetToLobby();
    });

    this.socket.on('connect', () => {
      const overlay = document.getElementById('maintenance-overlay');
      const debugEl = document.getElementById('debug-error-msg');
      if (overlay) overlay.style.display = 'none';
      if (debugEl) debugEl.textContent = '';
      console.log('[KanjiDuel] terhubung ke server');
      this.refreshDeckSummary(true);

      if (this.state.pendingJoinRoom && this.state.username) {
        this.socket.emit('room:join', {
          roomCode: this.state.pendingJoinRoom,
          playerName: this.state.username,
          secretId: this.state.secretId,
        }, (resp) => {
          if (resp?.ok) {
            this.state.view = 'room';
            this.state.roomCode = resp.roomCode;
            this.state.roomMode = resp.roomMode;
            this.state.roomPlayers = [resp.player];
            this.state.roomCanStart = false;
            this.state.roomChats = [];
            this.renderRoom();
            if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
          } else {
            UI.toast(resp?.error || 'Gagal join dari URL', { variant: 'error' });
          }
        });
        this.state.pendingJoinRoom = null;
      }
    });

    this.socket.on('disconnect', () => {
      const overlay = document.getElementById('maintenance-overlay');
      if (overlay) overlay.style.display = 'flex';
    });

    this.socket.on('connect_error', (err) => {
      const overlay = document.getElementById('maintenance-overlay');
      const debugEl = document.getElementById('debug-error-msg');
      if (overlay) overlay.style.display = 'flex';
      if (debugEl && err) debugEl.textContent = `[DEBUG] connect_error: ${err.message}`;
      console.error('[KanjiDuel] Socket Connect Error:', err);
    });
  },

  bindGlobalEvents() {
    document.body.addEventListener('change', (e) => {
      const target = e.target;
      if (target.id === 'create-level') {
        this.state.selectedLevel = target.value;
      }
      if (target.id === 'practice-timer') {
        this.state.practiceConfig.timerSeconds = Number(target.value) || 5;
        if (this.state.view === 'practiceSetup') this.renderPracticeSetup();
      }
    });

    document.body.addEventListener('click', (e) => {
      if (typeof AudioManager !== 'undefined') AudioManager.unlock();

      const target = e.target;
      const handle = (fn) => {
        try { fn(); }
        catch (err) { console.error('[click] error:', err); }
      };

      if (target.closest('#btn-audio-toggle')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') {
            const muted = AudioManager.toggleMute();
            const icon = document.getElementById('audio-icon');
            if (icon) icon.textContent = muted ? '🔇' : '🔊';
          }
        });
        return;
      }

      if (target.closest('#nav-home')) {
        handle(() => {
          if (this.state.roomCode && (this.state.view === 'room' || this.state.view === 'battle')) {
            UI.toast('Gunakan tombol di dalam room atau battle untuk keluar.', { variant: 'error' });
            return;
          }
          this.resetToLobby();
        });
        return;
      }

      const navBtn = target.closest('[data-go]');
      if (navBtn) {
        handle(() => {
          const next = navBtn.dataset.go;
          const inLiveRoom = this.state.roomCode && (this.state.view === 'room' || this.state.view === 'battle');

          if (inLiveRoom && next !== this.state.view) {
            UI.toast('Gunakan tombol di dalam room atau battle untuk berpindah.', { variant: 'error' });
            return;
          }

          if (next === 'lobby') this.resetToLobby();
          else if (next === 'room') {
            if (this.state.roomCode) {
              this.state.view = 'room';
              this.renderRoom();
            } else {
              this.resetToLobby();
            }
          } else if (next === 'battle') {
            if (this.state.battlePlayers?.length) {
              this.state.view = 'battle';
              this.renderBattle();
            } else {
              UI.toast('Belum ada battle aktif', { variant: 'error' });
            }
          } else if (next === 'practice') {
            this.goPracticeSetup();
          }
        });
        return;
      }

      const modePill = target.closest('[data-mode]');
      if (modePill && this.state.view === 'lobby') {
        handle(() => {
          const mode = modePill.dataset.mode;
          if (['1v1', '2v2'].includes(mode)) {
            this.state.selectedMode = mode;
            this.renderLobby();
          }
        });
        return;
      }

      if (target.closest('#btn-show-leaderboard')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.fetchJson('/api/leaderboard')
            .then((data) => {
              const modalHtml = Views.leaderboardModal(data);
              const div = document.createElement('div');
              div.id = 'leaderboard-container';
              div.innerHTML = modalHtml;
              document.body.appendChild(div);
            })
            .catch((err) => {
              console.error('Leaderboard fetch error:', err);
              UI.toast('Gagal memuat leaderboard', { variant: 'error' });
            });
        });
        return;
      }

      if (target.closest('#btn-close-leaderboard')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          document.getElementById('leaderboard-container')?.remove();
        });
        return;
      }

      if (target.closest('#btn-edit-username')) {
        handle(() => {
          this.state.username = null;
          this.renderLobby();
          setTimeout(() => {
            const input = UI.qs('#global-username-input');
            if (input) {
              input.value = localStorage.getItem('kanji-username') || '';
              input.focus();
            }
          }, 50);
        });
        return;
      }

      if (target.closest('#btn-save-username')) {
        handle(() => {
          const input = UI.qs('#global-username-input');
          const val = (input?.value || '').trim();
          if (!val) {
            UI.toast('Masukkan username', { variant: 'error' });
            return;
          }

          this.socket.emit('player:setUsername', {
            secretId: this.state.secretId,
            newName: val,
          }, (resp) => {
            if (!resp?.ok) {
              UI.toast(resp?.error || 'Username gagal disimpan', { variant: 'error' });
              return;
            }

            localStorage.setItem('kanji-username', val);
            this.state.username = val;
            this.render();
            this.refreshDeckSummary(true);

            if (this.state.pendingJoinRoom && this.socket?.connected) {
              this.socket.emit('room:join', {
                roomCode: this.state.pendingJoinRoom,
                playerName: this.state.username,
                secretId: this.state.secretId,
              }, (joinResp) => {
                if (joinResp?.ok) {
                  this.state.view = 'room';
                  this.state.roomCode = joinResp.roomCode;
                  this.state.roomMode = joinResp.roomMode;
                  this.state.roomPlayers = [joinResp.player];
                  this.state.roomCanStart = false;
                  this.state.roomChats = [];
                  this.renderRoom();
                  if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
                } else {
                  UI.toast(joinResp?.error || 'Gagal join dari URL', { variant: 'error' });
                }
              });
              this.state.pendingJoinRoom = null;
            }
          });
        });
        return;
      }

      if (target.closest('#btn-view-deck')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.state.view = 'deck';
          this.renderDeck();
          this.loadDeckData(true).then(() => this.renderDeck());
        });
        return;
      }

      if (target.closest('#btn-deck-back-lobby')) {
        handle(() => this.resetToLobby());
        return;
      }

      if (target.closest('#btn-practice-menu')) {
        handle(() => this.goPracticeSetup());
        return;
      }

      const practiceLevelBtn = target.closest('[data-practice-level]');
      if (practiceLevelBtn && this.state.view === 'practiceSetup') {
        handle(() => {
          const level = practiceLevelBtn.dataset.practiceLevel;
          if (!level) return;
          if ((this.state.deckSummary[level] || 0) === 0) return;
          this.state.practiceConfig.level = level;
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.renderPracticeSetup();
        });
        return;
      }

      if (target.closest('#btn-practice-back-lobby')) {
        handle(() => this.resetToLobby());
        return;
      }

      if (target.closest('#btn-start-practice')) {
        handle(() => this.startPracticeSession());
        return;
      }

      if (target.closest('#btn-practice-restart')) {
        handle(() => this.startPracticeSession());
        return;
      }

      if (target.closest('#btn-practice-settings')) {
        handle(() => {
          this.resetPracticeState();
          this.state.view = 'practiceSetup';
          this.renderPracticeSetup();
        });
        return;
      }

      if (target.closest('#btn-practice-finish-lobby')) {
        handle(() => this.resetToLobby());
        return;
      }

      if (target.closest('#btn-exit-practice')) {
        handle(() => {
          this.showConfirm({
            title: 'Keluar dari Latihan?',
            message: 'Progress latihan akan dihentikan dan kamu kembali ke pengaturan latihan.',
            confirmText: 'Ya, keluar',
            cancelText: 'Lanjut latihan',
            danger: false,
            onConfirm: () => {
              this.resetPracticeState();
              this.state.view = 'practiceSetup';
              this.renderPracticeSetup();
            },
          });
        });
        return;
      }

      if (target.closest('#btn-create')) {
        handle(() => {
          const name = this.state.username;
          const level = this.state.selectedLevel || 'n5';
          if (!name) { UI.toast('Username belum diset', { variant: 'error' }); return; }
          this.socket.emit('room:create', {
            mode: this.state.selectedMode,
            playerName: name,
            level,
            secretId: this.state.secretId,
          }, (resp) => {
            if (!resp?.ok) { UI.toast(resp?.error || 'Gagal membuat room', { variant: 'error' }); return; }
            if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
            this.state.view = 'room';
            this.state.roomCode = resp.roomCode;
            this.state.roomMode = resp.roomMode;
            this.state.roomLevel = level;
            this.state.roomPlayers = [resp.player];
            this.state.roomCanStart = false;
            this.state.roomChats = [];
            this.renderRoom();
            if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
          });
        });
        return;
      }

      if (target.closest('#btn-join')) {
        handle(() => {
          const code = (UI.qs('#join-code')?.value || '').trim().toUpperCase();
          const name = this.state.username;
          if (!code) { UI.toast('Masukkan kode room', { variant: 'error' }); return; }
          if (!name) { UI.toast('Username belum diset', { variant: 'error' }); return; }
          this.socket.emit('room:join', {
            roomCode: code,
            playerName: name,
            secretId: this.state.secretId,
          }, (resp) => {
            if (!resp?.ok) { UI.toast(resp?.error || 'Gagal join room', { variant: 'error' }); return; }
            if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
            this.state.view = 'room';
            this.state.roomCode = resp.roomCode;
            this.state.roomMode = resp.roomMode;
            this.state.roomPlayers = [resp.player];
            this.state.roomCanStart = false;
            this.state.roomChats = [];
            this.renderRoom();
            if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
          });
        });
        return;
      }

      if (target.closest('[data-join-room]')) {
        handle(() => {
          const code = target.closest('[data-join-room]').dataset.joinRoom;
          const name = this.state.username;
          if (!name) { UI.toast('Username belum diset', { variant: 'error' }); return; }
          this.socket.emit('room:join', {
            roomCode: code,
            playerName: name,
            secretId: this.state.secretId,
          }, (resp) => {
            if (!resp?.ok) { UI.toast(resp?.error || 'Gagal join room', { variant: 'error' }); return; }
            if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
            this.state.view = 'room';
            this.state.roomCode = resp.roomCode;
            this.state.roomMode = resp.roomMode;
            this.state.roomPlayers = [resp.player];
            this.state.roomCanStart = false;
            this.state.roomChats = [];
            this.renderRoom();
            if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
          });
        });
        return;
      }

      const answerBtn = target.closest('.n-answer__btn[data-answer]');
      if (answerBtn && !answerBtn.disabled) {
        handle(() => {
          const answer = answerBtn.dataset.answer;
          if (!answer) return;

          if (this.state.view === 'practiceBattle') {
            this.handlePracticeAnswer(answer);
            return;
          }

          if (this.state.view !== 'battle') return;
          if (this.state.answered || this.state.lastResult) return;

          this.state.selectedAnswer = answer;
          this.state.answered = true;
          this.renderBattle();

          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');

          const emitTimeout = setTimeout(() => {
            UI.toast('Timeout - coba lagi', { variant: 'error' });
            this.state.answered = false;
            this.state.selectedAnswer = null;
            this.renderBattle();
          }, 5000);

          this.socket.emit('round:answer', { answer }, (resp) => {
            clearTimeout(emitTimeout);
            if (!resp?.ok) {
              UI.toast(resp?.error || 'Gagal mengirim jawaban', { variant: 'error' });
              this.state.answered = false;
              this.state.selectedAnswer = null;
              this.renderBattle();
            }
          });
        });
        return;
      }

      const kickBtn = target.closest('[data-kick-player]');
      if (kickBtn) {
        handle(() => {
          const playerId = kickBtn.dataset.kickPlayer;
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.socket.emit('room:kick', { playerId }, (resp) => {
            if (!resp?.ok) UI.toast(resp?.error || 'Gagal melakukan kick', { variant: 'error' });
          });
        });
        return;
      }

      if (target.closest('#btn-ready')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.socket.emit('room:toggleReady', {}, (resp) => {
            if (!resp?.ok) UI.toast(resp?.error || 'Gagal toggle siap', { variant: 'error' });
          });
        });
        return;
      }

      if (target.closest('#btn-start')) {
        handle(() => {
          if (!this.state.roomCanStart) {
            UI.toast('Belum semua pemain siap', { variant: 'error' });
            return;
          }
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('shield');
          this.socket.emit('match:start', {}, (resp) => {
            if (!resp?.ok) UI.toast(resp?.error || 'Gagal memulai pertandingan', { variant: 'error' });
          });
        });
        return;
      }

      if (target.closest('#btn-leave')) {
        handle(() => {
          this.showConfirm({
            title: 'Keluar dari Room?',
            message: 'Kamu akan kembali ke lobby. Pemain lain akan melihat slot kosong.',
            confirmText: 'Ya, keluar',
            cancelText: 'Batal',
            danger: false,
            onConfirm: () => {
              if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
              this.performLeave();
            },
          });
        });
        return;
      }

      if (target.closest('#btn-switch-team')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          this.socket.emit('room:switchTeam', {}, (resp) => {
            if (!resp?.ok) UI.toast(resp?.error || 'Gagal pindah tim', { variant: 'error' });
          });
        });
        return;
      }

      if (target.closest('#btn-share-wa')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
          const url = `${window.location.origin}${window.location.pathname}?room=${this.state.roomCode}`;
          const text = `Ayo main Kanji Duel bersamaku! Join room: ${this.state.roomCode}\n\nKlik link ini: ${url}`;
          window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
        });
        return;
      }

      if (target.closest('#btn-send-chat')) {
        handle(() => {
          const input = UI.qs('#chat-input');
          const text = (input?.value || '').trim();
          if (!text) return;
          this.socket.emit('room:chat', { text }, (resp) => {
            if (!resp?.ok) UI.toast(resp?.error || 'Gagal mengirim pesan', { variant: 'error' });
          });
          input.value = '';
          input.focus();
        });
        return;
      }

      if (target.closest('#btn-leave-battle')) {
        handle(() => {
          this.showConfirm({
            title: 'Keluar dari Pertandingan?',
            message: 'Tim kamu akan langsung kalah. Yakin?',
            confirmText: 'Ya, keluar',
            cancelText: 'Lanjut main',
            danger: true,
            onConfirm: () => {
              this.socket.emit('room:leave', {});
              this.resetToLobby();
            },
          });
        });
        return;
      }

      if (target.closest('#btn-save-deck')) {
        handle(() => this.saveMatchDeck());
        return;
      }

      if (target.closest('#btn-back-room')) {
        handle(() => {
          if (typeof AudioManager !== 'undefined') AudioManager.bgm('room');
          this.state.view = 'room';
          this.state.lastResult = null;
          this.state.matchEnd = null;
          this.state.answered = false;
          this.state.selectedAnswer = null;
          if (this.state.roomPlayers?.length > 0) {
            this.state.roomPlayers.forEach((player) => { player.ready = false; });
          }
          this.renderRoom();
        });
        return;
      }

      if (target.closest('#btn-confirm-ok')) {
        handle(() => {
          const cb = this.state.pendingConfirm?.onConfirm;
          const returnView = this.state.pendingConfirmReturnView;
          this.state.pendingConfirm = null;
          this.state.pendingConfirmReturnView = null;
          this.state.view = returnView;
          if (cb) cb();
          else this.render();
        });
        return;
      }

      if (target.closest('#btn-confirm-cancel')) {
        handle(() => {
          this.state.pendingConfirm = null;
          this.state.view = this.state.pendingConfirmReturnView;
          this.state.pendingConfirmReturnView = null;
          this.render();
        });
        return;
      }
    });

    document.body.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      if (UI.qs('#join-code') === document.activeElement) {
        UI.qs('#btn-join')?.click();
      } else if (UI.qs('#chat-input') === document.activeElement) {
        UI.qs('#btn-send-chat')?.click();
      } else if ((this.state.view === 'battle' && !this.state.answered) || (this.state.view === 'practiceBattle' && !this.state.practiceSession?.answered)) {
        UI.qs('.n-answer__btn[data-answer]:not([disabled])')?.click();
      }
    });
  },

  render() {
    switch (this.state.view) {
      case 'lobby': this.renderLobby(); break;
      case 'room': this.renderRoom(); break;
      case 'battle': this.renderBattle(); break;
      case 'deck': this.renderDeck(); break;
      case 'practiceSetup': this.renderPracticeSetup(); break;
      case 'practiceBattle': this.renderPracticeBattle(); break;
      case 'confirm': this.renderConfirm(); break;
      default: this.renderLobby();
    }
  },

  renderOverlays() {
    return `${!this.state.username ? Views.usernameModal() : ''}${this.state.rewardFlash ? Views.rewardFlash(this.state.rewardFlash) : ''}`;
  },

  renderLobby() {
    document.getElementById('app').innerHTML = Views.lobby(this.state) + this.renderOverlays();
    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'lobby') {
      AudioManager.bgm('lobby');
      this.lastViewBGM = 'lobby';
    }
  },

  renderRoom() {
    document.getElementById('app').innerHTML = Views.room({
      code: this.state.roomCode,
      mode: this.state.roomMode,
      level: this.state.roomLevel,
      players: this.state.roomPlayers,
      capacity: this.state.roomMode === '2v2' ? 4 : 2,
      canStart: this.state.roomCanStart,
      chats: this.state.roomChats,
    }) + this.renderOverlays();
    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'room') {
      AudioManager.bgm('room');
      this.lastViewBGM = 'room';
    }
  },

  renderBattle() {
    document.getElementById('app').innerHTML = Views.battle({
      roomCode: this.state.roomCode,
      mode: this.state.battleMode,
      players: this.state.battlePlayers,
      roundNumber: this.state.roundNumber,
      maxRounds: this.state.maxRounds,
      question: this.state.question,
      options: this.state.options,
      answered: this.state.answered,
      selectedAnswer: this.state.selectedAnswer,
      lastResult: this.state.lastResult,
      matchEnd: this.state.matchEnd,
    }) + this.renderOverlays();
    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'battle') {
      AudioManager.bgm('battle');
      this.lastViewBGM = 'battle';
    }

    if (this.state.endsAt && !this.state.lastResult && !this.state.matchEnd) this.startTimer(this.state.endsAt);
    else this.stopTimer();
  },

  renderDeck() {
    document.getElementById('app').innerHTML = Views.deck(this.state) + this.renderOverlays();
    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'lobby') {
      AudioManager.bgm('lobby');
      this.lastViewBGM = 'lobby';
    }
  },

  renderPracticeSetup() {
    document.getElementById('app').innerHTML = Views.practiceSetup(this.state) + this.renderOverlays();
    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'lobby') {
      AudioManager.bgm('lobby');
      this.lastViewBGM = 'lobby';
    }
  },

  renderPracticeBattle() {
    const practice = this.state.practiceSession;
    if (!practice) {
      this.state.view = 'practiceSetup';
      this.renderPracticeSetup();
      return;
    }

    document.getElementById('app').innerHTML = Views.practiceBattle({
      level: practice.level,
      timerSeconds: practice.timerSeconds,
      roundNumber: practice.roundNumber,
      maxRounds: practice.maxRounds,
      question: practice.currentQuestion,
      options: practice.options,
      answered: practice.answered,
      selectedAnswer: practice.selectedAnswer,
      lastResult: practice.lastResult,
      practiceStats: practice.stats,
      practiceEnd: practice.summary,
    }) + this.renderOverlays();

    if (typeof AudioManager !== 'undefined' && this.lastViewBGM !== 'battle') {
      AudioManager.bgm('battle');
      this.lastViewBGM = 'battle';
    }

    if (practice.endsAt && !practice.lastResult && !practice.summary) this.startTimer(practice.endsAt, () => this.handlePracticeTimeout());
    else this.stopTimer();
  },

  renderConfirm() {
    if (!this.state.pendingConfirm) {
      this.state.view = this.state.pendingConfirmReturnView || 'lobby';
      return this.render();
    }
    document.getElementById('app').innerHTML = Views.confirmDialog(this.state.pendingConfirm);
  },

  performLeave() {
    this.socket.emit('room:leave', {}, () => this.resetToLobby());
  },

  showConfirm(opts) {
    this.state.pendingConfirm = opts;
    this.state.pendingConfirmReturnView = this.state.view;
    this.state.view = 'confirm';
    this.render();
  },

  startTimer(endsAt, onEnd = null) {
    this.stopTimer();
    const tick = () => {
      const rawRemaining = (endsAt - Date.now()) / 1000;
      const remaining = Math.max(0, rawRemaining);
      const el = UI.qs('#battle-timer');
      if (!el) return;
      el.textContent = UI.formatSeconds(remaining);

      if (rawRemaining <= 2.0 && rawRemaining > 0) {
        el.classList.add('n-timer--warning');
        const currentSec = Math.floor(rawRemaining);
        if (typeof AudioManager !== 'undefined' && currentSec !== this._lastTickSec) {
          this._lastTickSec = currentSec;
          AudioManager.sfx('tick');
        }
      } else {
        el.classList.remove('n-timer--warning');
      }

      if (rawRemaining <= 0) {
        this.stopTimer();
        if (typeof onEnd === 'function') onEnd();
      }
    };
    tick();
    this.timerInterval = setInterval(tick, 100);
  },

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
    this._lastTickSec = null;
  },

  clearPracticeAdvance() {
    if (this.practiceAdvanceTimeout) {
      clearTimeout(this.practiceAdvanceTimeout);
      this.practiceAdvanceTimeout = null;
    }
  },

  resetPracticeState() {
    this.stopTimer();
    this.clearPracticeAdvance();
    this.state.practiceSession = null;
  },

  goPracticeSetup() {
    if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
    this.loadDeckData(true).then(() => {
      this.state.practiceConfig.level = this.defaultPracticeLevel();
      this.state.view = 'practiceSetup';
      this.renderPracticeSetup();
      if (Object.values(this.state.deckSummary).every((count) => !count)) {
        UI.toast('Deck kamu masih kosong. Simpan kanji dari hasil battle dulu ya.', { variant: 'error' });
      }
    });
  },

  startPracticeSession() {
    this.loadDeckData().then(() => {
      const level = this.state.practiceConfig.level;
      const timerSeconds = Number(this.state.practiceConfig.timerSeconds) || 5;
      const source = Array.isArray(this.state.deckData[level]) ? this.state.deckData[level] : [];

      if (!source.length) {
        UI.toast(`Deck ${level.toUpperCase()} masih kosong`, { variant: 'error' });
        return;
      }

      const questions = this.shuffleArray(source).slice(0, Math.min(10, source.length)).map((item) => ({
        kanji: item.kanji,
        answer: item.answer,
        wrong: Array.isArray(item.wrong) ? item.wrong.slice(0, 3) : [],
      }));

      this.state.practiceSession = {
        level,
        timerSeconds,
        questions,
        currentIndex: 0,
        roundNumber: 1,
        maxRounds: questions.length,
        currentQuestion: null,
        options: [],
        answered: false,
        selectedAnswer: null,
        lastResult: null,
        summary: null,
        endsAt: null,
        stats: { correct: 0, wrong: 0, timeout: 0 },
        history: [],
      };

      this.startPracticeRound();
    });
  },

  startPracticeRound() {
    const practice = this.state.practiceSession;
    if (!practice) return;

    if (practice.currentIndex >= practice.questions.length) {
      this.finishPracticeSession();
      return;
    }

    const question = practice.questions[practice.currentIndex];
    practice.roundNumber = practice.currentIndex + 1;
    practice.currentQuestion = question;
    practice.options = this.shuffleArray([question.answer, ...(question.wrong || []).slice(0, 3)]);
    practice.answered = false;
    practice.selectedAnswer = null;
    practice.lastResult = null;
    practice.summary = null;
    practice.endsAt = Date.now() + (practice.timerSeconds * 1000);

    this.state.view = 'practiceBattle';
    this.renderPracticeBattle();
  },

  handlePracticeAnswer(answer) {
    const practice = this.state.practiceSession;
    if (!practice || practice.answered || practice.summary) return;

    practice.answered = true;
    practice.selectedAnswer = answer;
    this.stopTimer();

    const correct = answer === practice.currentQuestion.answer;
    this.finishPracticeRound({
      selectedAnswer: answer,
      correct,
      timedOut: false,
    });
  },

  handlePracticeTimeout() {
    const practice = this.state.practiceSession;
    if (!practice || practice.answered || practice.summary) return;
    practice.answered = true;
    practice.selectedAnswer = null;
    this.finishPracticeRound({
      selectedAnswer: null,
      correct: false,
      timedOut: true,
    });
  },

  finishPracticeRound({ selectedAnswer, correct, timedOut }) {
    const practice = this.state.practiceSession;
    if (!practice) return;

    if (correct) practice.stats.correct += 1;
    else if (timedOut) practice.stats.timeout += 1;
    else practice.stats.wrong += 1;

    const result = {
      roundNumber: practice.roundNumber,
      kanji: practice.currentQuestion.kanji,
      correctAnswer: practice.currentQuestion.answer,
      selectedAnswer,
      correct,
      timedOut,
    };

    practice.history.push(result);
    practice.lastResult = result;
    practice.endsAt = null;

    if (typeof AudioManager !== 'undefined') {
      if (correct) AudioManager.sfx('correct');
      else AudioManager.sfx('wrong');
    }

    this.renderPracticeBattle();
    this.clearPracticeAdvance();
    this.practiceAdvanceTimeout = setTimeout(() => {
      if (!this.state.practiceSession) return;
      this.state.practiceSession.currentIndex += 1;
      this.startPracticeRound();
    }, 1600);
  },

  finishPracticeSession() {
    const practice = this.state.practiceSession;
    if (!practice) return;

    const total = practice.history.length;
    const correct = practice.stats.correct;
    const wrong = practice.stats.wrong;
    const timeout = practice.stats.timeout;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

    practice.summary = {
      level: practice.level,
      timerSeconds: practice.timerSeconds,
      total,
      correct,
      wrong,
      timeout,
      accuracy,
    };
    practice.lastResult = null;
    practice.endsAt = null;
    this.state.view = 'practiceBattle';
    this.renderPracticeBattle();
  },

  saveMatchDeck() {
    if (!this.state.matchEnd) {
      UI.toast('Belum ada hasil pertandingan untuk disimpan', { variant: 'error' });
      return;
    }

    if (typeof AudioManager !== 'undefined') AudioManager.sfx('click');
    this.socket.emit('deck:saveMatch', { secretId: this.state.secretId }, (resp) => {
      if (!resp?.ok) {
        UI.toast(resp?.error || 'Gagal menyimpan deck', { variant: 'error' });
        return;
      }

      this.syncDeckCaches(resp.summary || this.state.deckSummary, null, resp.meta || this.state.deckMeta);
      const levelLabel = (resp.level || 'n5').toUpperCase();

      if ((resp.savedCount || 0) > 0) {
        this.flashReward({
          title: `NEW KANJI x${resp.savedCount}!`,
          subtitle: `${levelLabel} COLLECTION +${resp.savedCount}`,
          note: resp.skippedCount ? `${resp.skippedCount} duplikat dilewati` : 'Semua kanji baru berhasil masuk deck',
        });
      } else {
        UI.toast(`Semua kanji battle level ${levelLabel} sudah ada di deck.`, { variant: 'success' });
      }

      this.refreshDeckSummary(true);
    });
  },

  resetToLobby() {
    this.stopTimer();
    this.clearPracticeAdvance();
    this.clearRewardFlash();
    this.state.view = 'lobby';
    this.state.roomCode = null;
    this.state.roomMode = null;
    this.state.roomLevel = 'n5';
    this.state.roomPlayers = [];
    this.state.roomCanStart = false;
    this.state.roomChats = [];
    this.state.battleMode = null;
    this.state.battlePlayers = [];
    this.state.question = null;
    this.state.options = [];
    this.state.endsAt = null;
    this.state.answered = false;
    this.state.selectedAnswer = null;
    this.state.lastResult = null;
    this.state.matchEnd = null;
    this.state.pendingConfirm = null;
    this.state.pendingConfirmReturnView = null;
    this.state.practiceSession = null;
    this.lastViewBGM = null;
    this.render();
    this.refreshDeckSummary();
  },
};

document.addEventListener('DOMContentLoaded', () => Client.init());
