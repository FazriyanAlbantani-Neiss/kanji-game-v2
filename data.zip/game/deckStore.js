const fs = require('fs');
const path = require('path');

const DECK_FILE = path.join(__dirname, '..', 'data', 'userDecks.json');
const LEVELS = ['n5', 'n4', 'n3', 'n2', 'n1'];
const LEVEL_TOTALS = Object.freeze(
  LEVELS.reduce((acc, level) => {
    try {
      acc[level] = require(path.join(__dirname, '..', 'data', 'kanji', `${level}.js`)).length;
    } catch (_err) {
      acc[level] = 0;
    }
    return acc;
  }, {})
);

function createEmptyDeck() {
  return {
    n5: [],
    n4: [],
    n3: [],
    n2: [],
    n1: [],
  };
}

function ensureDeckFile() {
  if (!fs.existsSync(DECK_FILE)) {
    fs.writeFileSync(DECK_FILE, JSON.stringify({}, null, 2));
  }
}

function loadDecks() {
  ensureDeckFile();
  try {
    const parsed = JSON.parse(fs.readFileSync(DECK_FILE, 'utf-8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (_err) {
    return {};
  }
}

function saveDecks(data) {
  fs.writeFileSync(DECK_FILE, JSON.stringify(data, null, 2));
}

function normalizeUserDeck(rawDeck) {
  const base = createEmptyDeck();
  if (!rawDeck || typeof rawDeck !== 'object') return base;

  LEVELS.forEach((level) => {
    if (Array.isArray(rawDeck[level])) {
      base[level] = rawDeck[level]
        .filter((item) => item && item.kanji && item.answer)
        .map((item) => ({
          kanji: item.kanji,
          answer: item.answer,
          wrong: Array.isArray(item.wrong) ? item.wrong.slice(0, 3) : [],
          savedAt: item.savedAt || null,
        }));
    }
  });

  return base;
}

function getUserDeck(secretId) {
  const decks = loadDecks();
  return normalizeUserDeck(decks[secretId]);
}

function getDeckSummary(secretId) {
  const deck = getUserDeck(secretId);
  const summary = {};
  LEVELS.forEach((level) => {
    summary[level] = deck[level].length;
  });
  return summary;
}

function getBadgeMeta(percent) {
  if (percent >= 100) return { key: 'master', label: 'MASTER', tier: 4 };
  if (percent >= 75) return { key: 'gold', label: 'GOLD', tier: 3 };
  if (percent >= 50) return { key: 'silver', label: 'SILVER', tier: 2 };
  if (percent >= 25) return { key: 'bronze', label: 'BRONZE', tier: 1 };
  return { key: 'none', label: 'NONE', tier: 0 };
}

function getDeckMeta(secretId) {
  const summary = getDeckSummary(secretId);
  const meta = {};

  LEVELS.forEach((level) => {
    const count = summary[level] || 0;
    const total = LEVEL_TOTALS[level] || 0;
    const percent = total > 0 ? Number(((count / total) * 100).toFixed(1)) : 0;
    meta[level] = {
      count,
      total,
      percent,
      badge: getBadgeMeta(percent),
    };
  });

  return meta;
}

function getPlayerCollectionBadges(secretId) {
  if (!secretId) return [];
  const meta = getDeckMeta(secretId);
  return LEVELS
    .map((level) => ({ level, ...(meta[level] || {}) }))
    .filter((entry) => (entry.percent || 0) > 0)
    .map((entry) => ({
      type: 'collection',
      board: 'collection',
      level: entry.level,
      rank: 0,
      label: `${entry.level.toUpperCase()}`,
      percent: entry.percent || 0,
      badgeKey: entry.badge?.key || 'none',
    }));
}

function saveQuestionsToDeck(secretId, level, questions) {
  if (!secretId) {
    return { ok: false, error: 'Secret ID tidak valid' };
  }
  if (!LEVELS.includes(level)) {
    return { ok: false, error: 'Level deck tidak valid' };
  }

  const decks = loadDecks();
  const userDeck = normalizeUserDeck(decks[secretId]);
  const levelDeck = userDeck[level];
  const existingKanji = new Set(levelDeck.map((item) => item.kanji));

  let savedCount = 0;
  let skippedCount = 0;

  (questions || []).forEach((question) => {
    if (!question || !question.kanji || !question.answer) return;

    if (existingKanji.has(question.kanji)) {
      skippedCount++;
      return;
    }

    levelDeck.push({
      kanji: question.kanji,
      answer: question.answer,
      wrong: Array.isArray(question.wrong) ? question.wrong.slice(0, 3) : [],
      savedAt: new Date().toISOString(),
    });

    existingKanji.add(question.kanji);
    savedCount++;
  });

  decks[secretId] = userDeck;
  saveDecks(decks);

  return {
    ok: true,
    level,
    savedCount,
    skippedCount,
    totalCount: (questions || []).length,
    summary: getDeckSummary(secretId),
    meta: getDeckMeta(secretId),
  };
}

module.exports = {
  LEVELS,
  LEVEL_TOTALS,
  createEmptyDeck,
  getUserDeck,
  getDeckSummary,
  getDeckMeta,
  getPlayerCollectionBadges,
  saveQuestionsToDeck,
};
